"use strict";
var Control_Monad_Except = require("../Control.Monad.Except");
var Data_Either = require("../Data.Either");
var Data_Function = require("../Data.Function");
var Data_Symbol = require("../Data.Symbol");
var Prelude = require("../Prelude");
var Simple_JSON = require("../Simple.JSON");
var Type_Equality = require("../Type.Equality");
var Type_Row = require("../Type.Row");
var handler = function (event) {
    var v = Control_Monad_Except.runExcept(Simple_JSON.readJSON(Simple_JSON.readRecord()(Simple_JSON.readFieldsCons(new Data_Symbol.IsSymbol(function () {
        return "greeting";
    }))(Simple_JSON.readString)(Simple_JSON.readFieldsNil(Type_Equality.refl))(Type_Row.rowLacks()()()(Type_Row.rowLacking))())(Type_Row.listToRowCons(Type_Row.listToRowNil)()))(event));
    if (v instanceof Data_Either.Right) {
        return {
            statusCode: "200", 
            body: Simple_JSON.writeJSON(Simple_JSON.recordWriteForeign()(Simple_JSON.consWriteForeignFields(new Data_Symbol.IsSymbol(function () {
                return "greeting";
            }))(Simple_JSON.writeForeignInt)(Simple_JSON.nilWriteForeignFields(Type_Equality.refl))()(Type_Row.rowLacks()()()(Type_Row.rowLacking))()))(v.value0)
        };
    };
    if (v instanceof Data_Either.Left) {
        return {
            statusCode: "400", 
            body: "{\"error\": \"Couldn't parse JSON.\"}"
        };
    };
    throw new Error("Failed pattern match at Lambda line 13, column 3 - line 15, column 80: " + [ v.constructor.name ]);
};
module.exports = {
    handler: handler
};
